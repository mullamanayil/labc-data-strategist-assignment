# Senior Data Strategist — Take-Home Submission

Start with `ASSIGNMENT.md`. The sensitivity-label deck (`INFORMATION_PROTECTION.pptx`)
is provided alongside this repository.

## How to run my work
> Replace this section. A reviewer should be able to clone the repo and reproduce
> your output from these instructions alone.

## Assumptions
> List the assumptions you made about the data and the rollout.

## What I'd do with more time
> Be specific.
